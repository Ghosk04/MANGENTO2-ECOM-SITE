<p align="center"><b>Webverse_ten</b></p> 
<p>This is the main branch of the Ten Theme from Youtube Videos, to view the progress of a specific video switch to the corresponding branch</p>
  
<hr />

<div align="center">
  <img src="https://img.shields.io/badge/magento-^2.4.2-brightgreen.svg?logo=magento&longCache=true&style=flat-square" alt="Supported Magento Versions" />
  <a href="https://github.com/thewebverse" target="_blank"><img src="https://img.shields.io/badge/maintained%3F-yes-brightgreen.svg?style=flat-square" alt="Maintained - Yes" /></a>
  <a href="https://opensource.org/licenses/MIT" target="_blank"><img src="https://img.shields.io/badge/license-MIT-blue.svg" /></a>
 
</div>

<hr />

Check the youtube playlist here: https://www.youtube.com/watch?v=QPghCxs8mok&list=PLApOdfTXH6_4eEPADeweIZGte_rxzydV8
