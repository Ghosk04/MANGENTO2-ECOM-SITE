var config = {
    deps: [
        'js/sections/materials'
    ],
};
